
import rclpy
from rclpy.node import Node
import time

def main():
    rclpy.init()
    node = Node("test_node")
    print("Node started successfully!")
    
    # Safe loop (Has time.sleep)
    while True:
        print("Robot is moving...")
        time.sleep(1) 
