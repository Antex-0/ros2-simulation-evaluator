
import rclpy
from rclpy.node import Node
import time
import sys

class SimNode(Node):
    def __init__(self):
        super().__init__('robust_sim_node')
        # Log immediately to ROS logger
        self.get_logger().info('--- SIMULATION NODE STARTED ---')
        
        # Log to stdout with flush=True (Critical for file capture)
        print("[STDOUT] Node initialized and ready.", flush=True)
        
        self.counter = 0
        # Create a timer to run every 1 second
        self.timer = self.create_timer(1.0, self.timer_callback)

    def timer_callback(self):
        self.counter += 1
        msg = f"Simulation Step {self.counter}: Robot active."
        
        # Dual logging to ensure capture
        self.get_logger().info(msg)
        print(f"[STDOUT] {msg}", flush=True)

def main(args=None):
    # Initialize ROS context
    rclpy.init(args=args)
    
    node = SimNode()
    
    print("[STDOUT] Spinning node...", flush=True)
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        print("[STDOUT] Node stopped.", flush=True)

if __name__ == '__main__':
    main()
