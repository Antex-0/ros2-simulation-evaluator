import zipfile

# 1. Valid Node Code (with a safe loop)
node_code = """
import rclpy
from rclpy.node import Node
import time

def main():
    rclpy.init()
    node = Node("test_node")
    print("Node started successfully!")
    
    # Safe loop (Has time.sleep)
    while True:
        print("Robot is moving...")
        time.sleep(1) 
"""

# 2. Valid Package XML
xml_code = """<?xml version="1.0"?>
<package format="3">
  <name>good_pkg</name>
  <version>0.0.0</version>
  <description>Test</description>
  <maintainer email="test@test.com">User</maintainer>
  <license>MIT</license>
</package>
"""

# 3. Valid Setup.py
setup_code = """
from setuptools import setup

package_name = 'good_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='User',
    maintainer_email='user@todo.todo',
    description='Test Package',
    license='TODO',
    entry_points={
        'console_scripts': [
            'my_node = my_node:main',
        ],
    },
)
"""

print("Creating valid_package.zip...")
with zipfile.ZipFile('valid_package.zip', 'w') as z:
    z.writestr('my_node.py', node_code)
    z.writestr('package.xml', xml_code)
    z.writestr('setup.py', setup_code)

print("Done! You can now upload 'valid_package.zip' to the website.")